<?php

include('db.php');

if (isset($_POST['save'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "INSERT INTO users (name, email, phone) VALUES (?, ?, ?)";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("sss", $name, $email, $phone);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error adding user: " . $stmt->error; // Use $stmt->error for specific error
        }
        $stmt->close();
    } else {
        echo "Error preparing the insert statement: " . $conn->error;
    }
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "UPDATE users SET name=?, email=?, phone=? WHERE id=?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("sssi", $name, $email, $phone, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error updating user: " . $stmt->error; // Use $stmt->error for specific error
        }
        $stmt->close();
    } else {
        echo "Error preparing the update statement: " . $conn->error;
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $query = "DELETE FROM users WHERE id=?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error deleting user: " . $stmt->error; // Use $stmt->error for specific error
        }
        $stmt->close();
    } else {
        echo "Error preparing the delete statement: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>