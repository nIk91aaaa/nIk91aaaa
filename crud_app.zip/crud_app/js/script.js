document.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', function (e) {
        if (this.innerText === 'Delete' && !confirm('Are you sure you want to delete this user?')) {
            e.preventDefault();
        }
    });
});

function addUserToTable(userData) {
    var table = document.querySelector("table tbody");
    var row = document.createElement("tr");
    row.classList.add("user-row"); // Add the class for styling
    row.innerHTML = `
        <td>${userData.id}</td>
        <td>${userData.name}</td>
        <td>${userData.email}</td>
        <td>${userData.phone}</td>
        <td><button>Edit</button> <button>Delete</button></td>
    `;
    table.appendChild(row);
}

row.querySelector('.delete-btn').addEventListener('click', function (e) {
    if (!confirm('Are you sure you want to delete this user?')) {
        e.preventDefault();
    } else {
        // Call function to handle actual delete logic here, e.g., send a request to delete the user
        alert('User deleted: ' + userData.id);
        row.remove(); // Removes the row from the table (for visual effect)
    }
});

// Optional: Add event listener for the Edit button (if needed)
row.querySelector('.edit-btn').addEventListener('click', function () {
    alert('Edit functionality goes here for user: ' + userData.id);
    // Handle the edit action here, e.g., show a form to edit user data
});
