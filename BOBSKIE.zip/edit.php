<?php
// Include database connection
include('db.php');

// Fetch user data from the database
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM users WHERE id=$id");
    $user = $result->fetch_assoc();
} else {
    // Redirect if no ID is provided
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
   
    <style>
    body {
        background: url('https://www.pixelstalk.net/wp-content/uploads/2016/05/Backgrounds-Desktop-Black-HD-Wallpapers.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 400px; /* Ensure proper centering */
        margin: 50px auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        background-color: rgba(255, 255, 255, 0.4);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    h1 {
        text-align: center;
        color: #333;
        margin-bottom: 20px; /* Add space below heading */
    }
    input[type="text"], input[type="email"], input[type="phone"] {
        width: 100%; /* Full width for inputs */
        padding: 10px;
        margin: 10px 0; /* Vertical spacing between inputs */
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
        box-sizing: border-box; /* Ensure padding doesn't increase input width */
    }
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #4CAF50; /* Green button */
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049; /* Darker green on hover */
    }
    .back-link {
        display: block;
        text-align: center;
        margin-top: 20px; /* Space above back link */
    }
    .back-link a {
        color: #333;
        text-decoration: none;
        font-size: 16px;
    }
    .back-link a:hover {
        text-decoration: underline; /* Underline on hover */
    }

    </style>
</head>
<body>
<br><br><br><br><br>
    <div class="container">
        <h1>Edit User</h1>
        
        <!-- Edit Form -->
        <form action="process.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
            
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?php echo $user['name']; ?>" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>

            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required>

            <input type="submit" name="update" value="Update User">
        </form>

        <!-- Back Link -->
        <div class="back-link">
            <a href="index.php">Back to Users List</a>
        </div>
    </div>

</body>
</html>
