<?php
// Include the database connection
include('db.php');

// Check if the form for adding a user is submitted
if (isset($_POST['save'])) {
    // Get the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Insert query
    $query = "INSERT INTO users (name, email, phone) VALUES (?, ?, ?)";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("sss", $name, $email, $phone);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error adding user: " . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing the insert statement.";
    }
}

// Check if the form for updating a user is submitted
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "UPDATE users SET name=?, email=?, phone=? WHERE id=?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("sssi", $name, $email, $phone, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error updating user: " . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing the update statement.";
    }
}


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

   
    $query = "DELETE FROM users WHERE id=?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error deleting user: " . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing the delete statement.";
    }
}

// Close the database connection
$conn->close();
?>
