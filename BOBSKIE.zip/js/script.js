document.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', function (e) {
        if (this.innerText === 'Delete' && !confirm('Are you sure you want to delete this user?')) {
            e.preventDefault();
        }
    });
});

function addUserToTable(userData) {
    var table = document.querySelector("table tbody");
    var row = document.createElement("tr");
    row.classList.add("user-row"); // Add the class for styling
    row.innerHTML = `
        <td>${userData.id}</td>
        <td>${userData.name}</td>
        <td>${userData.email}</td>
        <td>${userData.phone}</td>
        <td><button>Edit</button> <button>Delete</button></td>
    `;
    table.appendChild(row);
}